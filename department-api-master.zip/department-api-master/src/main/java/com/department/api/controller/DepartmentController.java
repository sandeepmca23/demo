package com.department.api.controller;

import com.department.api.dto.APIResponse;
import com.department.api.dto.DepartmentDTO;
import com.department.api.dto.DepartmentEmployeeDTO;
import com.department.api.dto.DepartmentRequestDTO;
import com.department.api.dto.DepartmentSearchCriteriaDTO;
import com.department.api.enums.Status;
import com.department.api.mapper.DepartmentMapper;
import com.department.api.service.DepartmentService;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import lombok.AllArgsConstructor;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@AllArgsConstructor
@RequestMapping("/api/v1/")
@RestController
public class DepartmentController {


    private final DepartmentService departmentService;
    private final DepartmentMapper departmentMapper;


    
    @Operation(summary = "Create a new Department", description = "Add a new department to the system")
    @PostMapping("/department")
    public ResponseEntity<APIResponse<DepartmentDTO>> createDepartment(
            @Valid @RequestBody DepartmentRequestDTO departmentRequestDTO) {
        DepartmentDTO departmentDTO = departmentMapper.departmentRequestDTOToDepartmentDTO(departmentRequestDTO);
        DepartmentDTO result = departmentService.createDepartment(departmentDTO);
        APIResponse<DepartmentDTO> responseDTO = APIResponse
                .<DepartmentDTO>builder()
                .status(Status.SUCCESS.getValue())
                .results(result)
                .build();
        return new ResponseEntity<>(responseDTO, HttpStatus.CREATED);
    }

    @Operation(summary = "Search all departments using pagination",
            description = "Returns a list of departments")
    @GetMapping("/departments")
    public ResponseEntity<APIResponse<List<DepartmentDTO>>> getAllDepartments() {
    	List<DepartmentDTO> result = departmentService.getAllDepartments();
        APIResponse<List<DepartmentDTO>> responseDTO = APIResponse
                .<List<DepartmentDTO>>builder()
                .status(Status.SUCCESS.getValue())
                .results(result)
                .build();
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
  

    @Operation(summary = "Find department by ID",
            description = "Returns a single department")
    @GetMapping("/department/{id}/employees/")
    public ResponseEntity<APIResponse<DepartmentEmployeeDTO>> getDepartmenByIdtWithEmployeeList(@PathVariable("id") String id) {
        DepartmentEmployeeDTO result = departmentService.getDepartmenByIdtWithEmployeeList(id);
        APIResponse<DepartmentEmployeeDTO> responseDTO = APIResponse
                .<DepartmentEmployeeDTO>builder()
                .status(Status.SUCCESS.getValue())
                .results(result)
                .build();
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
    
    
    @Operation(summary = "Find department by ID",
            description = "Returns a single department")
    @GetMapping("/department/employees")
    public ResponseEntity<APIResponse< List<DepartmentEmployeeDTO>>> getDepartmenByIdtWithEmployeeList() {
        List<DepartmentEmployeeDTO> result = departmentService.getDepartmenByIdtWithEmployeeList();
        APIResponse<List<DepartmentEmployeeDTO>> responseDTO = APIResponse
                .<List<DepartmentEmployeeDTO>>builder()
                .status(Status.SUCCESS.getValue())
                .results(result)
                .build();
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }
   
    

    @Operation(summary = "Find department by ID",
            description = "Returns a single department")
    @GetMapping("/departments/{id}")
    public ResponseEntity<APIResponse<DepartmentDTO>> getDepartmentById(@PathVariable("id") String id) {
        DepartmentDTO result = departmentService.getDepartmentById(id);
        APIResponse<DepartmentDTO> responseDTO = APIResponse
                .<DepartmentDTO>builder()
                .status(Status.SUCCESS.getValue())
                .results(result)
                .build();
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);

    }
    
    


    @Operation(summary = "Update an existing department")
    @PutMapping("/{id}")
    public ResponseEntity<APIResponse<DepartmentDTO>> updateDepartment(
            @Valid @RequestBody DepartmentRequestDTO departmentRequestDTO,
            @PathVariable("id") String id) {
        DepartmentDTO departmentDTO = departmentMapper.departmentRequestDTOToDepartmentDTO(departmentRequestDTO);
        DepartmentDTO result = departmentService.updateDepartment(departmentDTO, id);
        APIResponse<DepartmentDTO> responseDTO = APIResponse
                .<DepartmentDTO>builder()
                .status(Status.SUCCESS.getValue())
                .results(result)
                .build();
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);

    }


    @Operation(summary = "Delete a department by ID")
    @DeleteMapping("/{id}")
    public ResponseEntity<APIResponse<String>> deleteDepartment(@PathVariable("id") String id) {
        departmentService.deleteDepartment(id);
        String result = "Department deleted successfully";
        APIResponse<String> responseDTO = APIResponse
                .<String>builder()
                .status(Status.SUCCESS.getValue())
                .results(result)
                .build();
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);

    }
    
    @Operation(summary = "Search all departments using pagination",
            description = "Returns a list of departments")
    @PostMapping("/search")
    public ResponseEntity<APIResponse<Page<DepartmentDTO>>> getAllDepartmentsUsingPagination(
            @Valid @RequestBody DepartmentSearchCriteriaDTO departmentSearchCriteriaDTO) {
        Page<DepartmentDTO> result = departmentService.getAllDepartmentsUsingPagination(departmentSearchCriteriaDTO);
        APIResponse<Page<DepartmentDTO>> responseDTO = APIResponse
                .<Page<DepartmentDTO>>builder()
                .status(Status.SUCCESS.getValue())
                .results(result)
                .build();
        return new ResponseEntity<>(responseDTO, HttpStatus.OK);
    }

}
