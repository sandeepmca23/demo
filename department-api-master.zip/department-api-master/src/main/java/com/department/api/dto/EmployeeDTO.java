package com.department.api.dto;

import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeDTO {

	private String id;
	private String name;
	private String position;
	private String email;
	private BigDecimal salary;

}
