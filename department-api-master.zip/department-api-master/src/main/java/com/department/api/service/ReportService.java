package com.department.api.service;

import com.department.api.dto.FileDTO;
import com.department.api.enums.ReportLanguage;
import net.sf.jasperreports.engine.JRException;

import java.io.IOException;

public interface ReportService {

    FileDTO generateDepartmentsExcelReport() throws JRException;

    FileDTO generateEmployeesExcelReport() throws JRException;

    FileDTO generatePdfFullReport(ReportLanguage language) throws JRException;

    FileDTO generateAndZipReports() throws JRException, IOException;

    FileDTO generateMultiSheetExcelReport() throws JRException;

    FileDTO generateCombinedPdfReport(ReportLanguage language) throws JRException;
}
