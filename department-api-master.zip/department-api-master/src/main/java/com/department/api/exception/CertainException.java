package com.department.api.exception;

public class CertainException {

}
