package com.department.api.dto;

import lombok.*;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class DepartmentReportDTO {

	private String id;
	private String name;
	private String location;
	private Integer totalEmployees;
	private LocalDateTime createdAt;
	private LocalDateTime updatedAt;

}
