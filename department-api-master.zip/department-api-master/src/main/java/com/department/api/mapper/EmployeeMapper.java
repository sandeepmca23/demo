package com.department.api.mapper;

import com.department.api.dto.EmployeeAndDepartmentDTO;
import com.department.api.dto.EmployeeDTO;
import com.department.api.dto.EmployeeReportDTO;
import com.department.api.dto.EmployeeRequestDTO;
import com.department.api.entity.Employee;
import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import java.util.List;

@Mapper(componentModel = "spring")
public interface EmployeeMapper {


    Employee employeeDtoToEmployee(EmployeeDTO employeeDTO);
    
    EmployeeDTO employeeToEmployeeDto(Employee employee);

    List<Employee> employeeDtoToEmployee(List<EmployeeDTO> employeeDTOList);
    List<EmployeeDTO> employeeToEmployeeDto(List<Employee> employeeList);

    EmployeeDTO employeeRequestDTOToEmployeeDTO(EmployeeRequestDTO employeeRequestDTO);

    @Mapping(target = "name", expression = "java(employee.getDepartment() != null ? employee.getDepartment().getName() : null)")
    EmployeeReportDTO employeeToEmployeeReportDto(Employee employee);

    @Mapping(target = "name", expression = "java(employeeList.getDepartment() != null ? employeeList.getDepartment().getName() : null)")
    List<EmployeeReportDTO> employeeToEmployeeReportDto(List<Employee> employeeList);

    EmployeeAndDepartmentDTO employeeToEmployeeAndDepartmentDto(Employee employee);

    List<EmployeeAndDepartmentDTO> employeeToEmployeeAndDepartmentDto(List<Employee> employeeList);

}
