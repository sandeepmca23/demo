package com.department.api.service;


import net.sf.jasperreports.engine.JRException;

public interface EmailService {

    Boolean sendEmailWithoutAttachment();

    Boolean sendEmailWithAttachment() throws JRException;
}
