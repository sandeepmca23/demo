package com.department.api.service;

import com.department.api.dto.EmployeeAndDepartmentDTO;
import com.department.api.dto.EmployeeDTO;
import com.department.api.dto.EmployeeSearchCriteriaDTO;
import org.springframework.data.domain.Page;

import java.util.List;

public interface EmployeeService {

    EmployeeDTO createEmployee(String departmentId, EmployeeDTO employeeDTO);

    Page<EmployeeDTO> getAllEmployeesUsingPagination(EmployeeSearchCriteriaDTO employeeSearchCriteriaDTO);

    List<EmployeeDTO> getEmployeesByDepartmentId(String departmentId);
    
  

    EmployeeDTO getEmployeeById(String departmentId, String employeeId);
    
    EmployeeAndDepartmentDTO getEmployeeById(String employeeId);

    EmployeeDTO updateEmployeeById(String departmentId, String employeeId, EmployeeDTO employeeDTO);

    void deleteEmployee(String departmentId, String employeeId);

    EmployeeAndDepartmentDTO getEmployeeAndDepartmentByEmployeeEmail(String email);
    
    List<EmployeeDTO> getAllEmployees();
}
