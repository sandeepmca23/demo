package com.department.api.service.impl;

import com.department.api.dto.EmployeeAndDepartmentDTO;
import com.department.api.dto.EmployeeDTO;
import com.department.api.dto.EmployeeSearchCriteriaDTO;
import com.department.api.entity.Department;
import com.department.api.entity.Employee;
import com.department.api.exception.BusinessLogicException;
import com.department.api.exception.ResourceAlreadyExistException;
import com.department.api.exception.ResourceNotFoundException;
import com.department.api.mapper.EmployeeMapper;
import com.department.api.repository.DepartmentRepository;
import com.department.api.repository.EmployeeRepository;
import com.department.api.service.EmployeeService;
import com.department.api.utils.SortItem;
import com.department.api.utils.Utils;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@AllArgsConstructor
@Service
public class EmployeeServiceImpl implements EmployeeService {

	private final EmployeeRepository employeeRepository;
	private final DepartmentRepository departmentRepository;
	private final EmployeeMapper employeeMapper;

	private static final String DEPARTMENT = "Department";
	private static final String EMPLOYEE = "Employee";
	private static final String EMPLOYEE_NOT_BELONG_TO_DEPARTMENT = "Employee does not belong to Department";

	@Override
	public EmployeeDTO createEmployee(String departmentId, EmployeeDTO employeeDTO) {

		Employee employeeRecordFromDB = employeeRepository.findByEmail(employeeDTO.getEmail());

		if (employeeRecordFromDB != null) {
			throw new ResourceAlreadyExistException(EMPLOYEE, "email", employeeDTO.getEmail());
		}

		Employee employee = employeeMapper.employeeDtoToEmployee(employeeDTO);

		Department departmentRecordFromDB = departmentRepository.findById(departmentId)
				.orElseThrow(() -> new ResourceNotFoundException(DEPARTMENT, "id", departmentId));

		employee.setDepartment(departmentRecordFromDB);

		Employee savedEmployee = employeeRepository.save(employee);

		return employeeMapper.employeeToEmployeeDto(savedEmployee);
	}

	@Override
	public Page<EmployeeDTO> getAllEmployeesUsingPagination(EmployeeSearchCriteriaDTO employeeSearchCriteriaDTO) {

		Integer page = employeeSearchCriteriaDTO.getPage();
		Integer size = employeeSearchCriteriaDTO.getSize();
		List<SortItem> sortList = employeeSearchCriteriaDTO.getSortList();

		// this pageable will be used for the pagination.
		Pageable pageable = Utils.createPageableBasedOnPageAndSizeAndSorting(sortList, page, size);

		Page<Employee> recordsFromDb = employeeRepository.getAllEmployeesUsingPagination(employeeSearchCriteriaDTO,
				pageable);

		List<EmployeeDTO> result = employeeMapper.employeeToEmployeeDto(recordsFromDb.getContent());

		return new PageImpl<>(result, pageable, recordsFromDb.getTotalElements());
	}

	@Override
	public List<EmployeeDTO> getAllEmployees() {
		List<Employee> recordsFromDb = employeeRepository.findAll();
		List<EmployeeDTO> result = employeeMapper.employeeToEmployeeDto(recordsFromDb);
		return  result;
	}

	@Override
	public List<EmployeeDTO> getEmployeesByDepartmentId(String departmentId) {

		List<Employee> employeesFromDB = employeeRepository.findByDepartmentId(departmentId);

		return employeeMapper.employeeToEmployeeDto(employeesFromDB);
	}

	@Override
	public EmployeeDTO getEmployeeById(String departmentId, String employeeId) {

		Department departmentRecordFromDB = departmentRepository.findById(departmentId)
				.orElseThrow(() -> new ResourceNotFoundException(DEPARTMENT, "id", departmentId));

		Employee employeeRecordFromDB = employeeRepository.findById(employeeId)
				.orElseThrow(() -> new ResourceNotFoundException(EMPLOYEE, "id", employeeId));

		if (!employeeBelongsToDepartment(departmentRecordFromDB, employeeRecordFromDB)) {
			throw new BusinessLogicException(EMPLOYEE_NOT_BELONG_TO_DEPARTMENT);
		}

		return employeeMapper.employeeToEmployeeDto(employeeRecordFromDB);
	}

	@Override
	public EmployeeDTO updateEmployeeById(String departmentId, String employeeId, EmployeeDTO employeeDTO) {

		Department departmentRecordFromDB = departmentRepository.findById(departmentId)
				.orElseThrow(() -> new ResourceNotFoundException(DEPARTMENT, "id", departmentId));

		Employee employeeRecordFromDB = employeeRepository.findById(employeeId)
				.orElseThrow(() -> new ResourceNotFoundException(EMPLOYEE, "id", employeeId));

		if (!employeeBelongsToDepartment(departmentRecordFromDB, employeeRecordFromDB)) {
			throw new BusinessLogicException(EMPLOYEE_NOT_BELONG_TO_DEPARTMENT);
		}

		// just to be safe that the object does not have another id
		employeeDTO.setId(employeeId);

		Employee recordToBeSaved = employeeMapper.employeeDtoToEmployee(employeeDTO);

		// assign the post to the current comment
		recordToBeSaved.setDepartment(departmentRecordFromDB);

		Employee savedEmployeeRecord = employeeRepository.save(recordToBeSaved);

		return employeeMapper.employeeToEmployeeDto(savedEmployeeRecord);
	}

	@Override
	public void deleteEmployee(String departmentId, String employeeId) {

		Department departmentRecordFromDB = departmentRepository.findById(departmentId)
				.orElseThrow(() -> new ResourceNotFoundException(DEPARTMENT, "id", departmentId));

		Employee employeeRecordFromDB = employeeRepository.findById(employeeId)
				.orElseThrow(() -> new ResourceNotFoundException(EMPLOYEE, "id", employeeId));

		if (!employeeBelongsToDepartment(departmentRecordFromDB, employeeRecordFromDB)) {
			throw new BusinessLogicException(EMPLOYEE_NOT_BELONG_TO_DEPARTMENT);
		}

		employeeRepository.delete(employeeRecordFromDB);

	}

	@Override
	public EmployeeAndDepartmentDTO getEmployeeAndDepartmentByEmployeeEmail(String email) {

		Employee employeeRecordFromDB = employeeRepository.getEmployeeAndDepartmentByEmployeeEmail(email);

		if (employeeRecordFromDB == null) {
			throw new ResourceNotFoundException(EMPLOYEE, "email", email);
		}

		return employeeMapper.employeeToEmployeeAndDepartmentDto(employeeRecordFromDB);
	}

	private boolean employeeBelongsToDepartment(Department departmentRecordFromDB, Employee employeeRecordFromDB) {

		if (departmentRecordFromDB == null || employeeRecordFromDB.getDepartment() == null) {
			return false;
		}

		String departmentId = employeeRecordFromDB.getDepartment().getId();
		return departmentId != null && departmentId.equals(departmentRecordFromDB.getId());
	}

	@Override
	public EmployeeAndDepartmentDTO getEmployeeById(String employeeId) {
		Employee employeeRecordFromDB = employeeRepository.findById(employeeId)
				.orElseThrow(() -> new ResourceNotFoundException(EMPLOYEE, "id", employeeId));
		EmployeeAndDepartmentDTO employeeAndDepartmentDTO=employeeMapper.employeeToEmployeeAndDepartmentDto(employeeRecordFromDB);
		return employeeAndDepartmentDTO;
	}

	

}
