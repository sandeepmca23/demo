package com.department.api.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Size;
import lombok.*;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class DepartmentRequestDTO {


    @NotEmpty(message = "Department name should not be null or empty")
    @Size(min = 2, message = "Department name should have at least 2 characters")
    private String name;

    @NotEmpty(message = "Department location should not be null or empty")
    @Size(min = 2, message = "Department location should have at least 10 characters")
    private String location;

    
  

}
