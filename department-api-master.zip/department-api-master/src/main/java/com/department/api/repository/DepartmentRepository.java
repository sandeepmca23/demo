package com.department.api.repository;

import com.department.api.dto.DepartmentSearchCriteriaDTO;
import com.department.api.entity.Department;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

public interface DepartmentRepository extends JpaRepository<Department, String> {

    Department findByName(String name);


    @Query(value = """
            select dep from Department dep
            where ( :#{#criteria.name} IS NULL OR LOWER(dep.name) LIKE LOWER( CONCAT(:#{#criteria.name}, '%') ) )
            and ( :#{#criteria.location} IS NULL OR LOWER(dep.name) LIKE LOWER( CONCAT(:#{#criteria.location}, '%') ) )
            
            """)
    Page<Department> getAllDepartmentsUsingPagination(
            @Param("criteria") DepartmentSearchCriteriaDTO departmentSearchCriteriaDTO,
            Pageable pageable);

}
