package com.department.api.dto;

import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeReportDTO {

	private String id;
	private String name;
	private String position;
	private String email;
	private BigDecimal salary;
	private String departmentName;
	private LocalDateTime createdAt;
	private LocalDateTime updatedAt;

}
