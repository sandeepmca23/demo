package com.department.api.dto;

import lombok.*;

import java.math.BigDecimal;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class EmployeeAndDepartmentDTO {

    private String id;
    private String name;
    private String position;
    private String email;
    private BigDecimal salary;
    private DepartmentDTO department;


    @Getter
    @Setter
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class DepartmentDTO {

        private String id;
        private String name;
        private String location;
       

    }

}
