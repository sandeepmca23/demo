package com.department.api.service.impl;

import com.department.api.dto.DepartmentDTO;
import com.department.api.dto.DepartmentEmployeeDTO;
import com.department.api.dto.DepartmentSearchCriteriaDTO;
import com.department.api.entity.Department;
import com.department.api.exception.ResourceAlreadyExistException;
import com.department.api.exception.ResourceNotFoundException;
import com.department.api.mapper.DepartmentMapper;
import com.department.api.repository.DepartmentRepository;
import com.department.api.service.DepartmentService;
import com.department.api.utils.SortItem;
import com.department.api.utils.Utils;
import lombok.AllArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@AllArgsConstructor
@Service
public class DepartmentServiceImpl implements DepartmentService {

	private final DepartmentRepository departmentRepository;
	private final DepartmentMapper departmentMapper;

	private static final String DEPARTMENT = "Department";

	@Override
	public DepartmentDTO createDepartment(DepartmentDTO departmentDTO) {

		Department recordFromDB = departmentRepository.findByName(departmentDTO.getName());

		if (recordFromDB != null) {
			throw new ResourceAlreadyExistException(DEPARTMENT, "departmentCode", departmentDTO.getName());
		}

		Department recordToBeSaved = departmentMapper.departmentDtoToDepartment(departmentDTO);

		Department savedRecord = departmentRepository.save(recordToBeSaved);

		return departmentMapper.departmentToDepartmentDto(savedRecord);
	}

	@Override
	public Page<DepartmentDTO> getAllDepartmentsUsingPagination(
			DepartmentSearchCriteriaDTO departmentSearchCriteriaDTO) {

		Integer page = departmentSearchCriteriaDTO.getPage();
		Integer size = departmentSearchCriteriaDTO.getSize();
		List<SortItem> sortList = departmentSearchCriteriaDTO.getSortList();

		// this pageable will be used for the pagination.
		Pageable pageable = Utils.createPageableBasedOnPageAndSizeAndSorting(sortList, page, size);

		Page<Department> recordsFromDb = departmentRepository
				.getAllDepartmentsUsingPagination(departmentSearchCriteriaDTO, pageable);

		List<DepartmentDTO> result = departmentMapper.departmentToDepartmentDto(recordsFromDb.getContent());

		return new PageImpl<>(result, pageable, recordsFromDb.getTotalElements());
	}

	@Override
	public DepartmentDTO getDepartmentById(String id) {

		Department recordFromDB = departmentRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException(DEPARTMENT, "id", id));

		return departmentMapper.departmentToDepartmentDto(recordFromDB);
	}

	@Override
	public DepartmentDTO updateDepartment(DepartmentDTO departmentDTO, String id) {

		Department recordFromDB = departmentRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException(DEPARTMENT, "id", id));

		// just to be safe that the object does not have another id
		departmentDTO.setId(id);

		Department recordToBeSaved = departmentMapper.departmentDtoToDepartment(departmentDTO);
		// I had to set again the employees otherwise I would lose the reference
		recordToBeSaved.setEmployees(recordFromDB.getEmployees());

		Department savedRecord = departmentRepository.save(recordToBeSaved);

		return departmentMapper.departmentToDepartmentDto(savedRecord);
	}

	@Override
	public void deleteDepartment(String id) {

		Department recordFromDB = departmentRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException(DEPARTMENT, "id", id));

		departmentRepository.delete(recordFromDB);

	}

	@Override
	public List<DepartmentDTO> getAllDepartments() {
		List<Department> departments = departmentRepository.findAll();
		List<DepartmentDTO> result = departmentMapper.departmentToDepartmentDto(departments);
		return result;
	}

	@Override
	public DepartmentEmployeeDTO getDepartmenByIdtWithEmployeeList(String id) {
		Department recordFromDB = departmentRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException(DEPARTMENT, "id", id));
		DepartmentEmployeeDTO result = departmentMapper.departmentToDepartmentEmployeDto(recordFromDB);
		return result;
	}

	@Override
	public List<DepartmentEmployeeDTO> getDepartmenByIdtWithEmployeeList() {
		List<Department> departments = departmentRepository.findAll();
		List<DepartmentEmployeeDTO> result = departmentMapper.departmentToDepartmentEmployeDto(departments);
		return result;
	}
}
