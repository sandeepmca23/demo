package com.department.api.mapper;

import java.util.List;

import org.mapstruct.Mapper;
import org.mapstruct.Mapping;

import com.department.api.dto.DepartmentDTO;
import com.department.api.dto.DepartmentEmployeeDTO;
import com.department.api.dto.DepartmentReportDTO;
import com.department.api.dto.DepartmentRequestDTO;
import com.department.api.entity.Department;

@Mapper(componentModel = "spring", uses = {EmployeeMapper.class})
public interface DepartmentMapper {

    Department departmentDtoToDepartment(DepartmentDTO departmentDTO);
    DepartmentDTO departmentToDepartmentDto(Department department);

    List<Department> departmentDtoToDepartment(List<DepartmentDTO> departmentDTOList);
    List<DepartmentDTO> departmentToDepartmentDto(List<Department> departmentList);
    List<DepartmentEmployeeDTO> departmentToDepartmentEmployeDto(List<Department> departmentList);
    DepartmentEmployeeDTO departmentToDepartmentEmployeDto(Department department);

    DepartmentDTO departmentRequestDTOToDepartmentDTO(DepartmentRequestDTO departmentRequestDTO);

    @Mapping(target = "totalEmployees", expression = "java(department.getEmployees() != null ? department.getEmployees().size() : 0)")
    DepartmentReportDTO departmentToDepartmentReportDto(Department department);

    @Mapping(target = "totalEmployees", expression = "java(departmentList.getEmployees() != null ? departmentList.getEmployees().size() : 0)")
    List<DepartmentReportDTO> departmentToDepartmentReportDto(List<Department> departmentList);

}
