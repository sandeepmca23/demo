package com.department.api.service;

import java.util.List;

import org.springframework.data.domain.Page;

import com.department.api.dto.DepartmentDTO;
import com.department.api.dto.DepartmentEmployeeDTO;
import com.department.api.dto.DepartmentSearchCriteriaDTO;

public interface DepartmentService {

	DepartmentDTO createDepartment(DepartmentDTO departmentDTO);

	Page<DepartmentDTO> getAllDepartmentsUsingPagination(DepartmentSearchCriteriaDTO departmentSearchCriteriaDTO);

	List<DepartmentDTO> getAllDepartments();

	DepartmentDTO getDepartmentById(String id);

	DepartmentEmployeeDTO getDepartmenByIdtWithEmployeeList(String id);

	List<DepartmentEmployeeDTO> getDepartmenByIdtWithEmployeeList();

	DepartmentDTO updateDepartment(DepartmentDTO departmentDTO, String id);

	void deleteDepartment(String id);

}
