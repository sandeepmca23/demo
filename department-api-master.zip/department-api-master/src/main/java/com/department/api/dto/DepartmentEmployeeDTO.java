package com.department.api.dto;

import java.util.Set;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import lombok.ToString;

@Getter
@Setter
@ToString
@NoArgsConstructor
@AllArgsConstructor
public class DepartmentEmployeeDTO {
	private String id;
	private String name;
	private String location;
	private Set<EmployeeDTO> employees;
}
