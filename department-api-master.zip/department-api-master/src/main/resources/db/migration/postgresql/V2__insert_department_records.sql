INSERT INTO departments (id, name, location, created_at, updated_at)
VALUES
    ('1a2b3c4d-5e6f-7g8h-9i0j-abcdefgh111111', 'Human Resources', 'INDIA', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
    ('1a2b3c4d-5e6f-7g8h-9i0j-abcdefgh222222', 'Information Technology', 'USR', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
    ('1a2b3c4d-5e6f-7g8h-9i0j-abcdefgh333333', 'Marketing', 'UAE', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP),
    ('1a2b3c4d-5e6f-7g8h-9i0j-abcdefgh444444', 'Sales', 'USA', CURRENT_TIMESTAMP, CURRENT_TIMESTAMP);
