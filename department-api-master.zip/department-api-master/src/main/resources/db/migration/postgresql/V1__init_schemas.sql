CREATE TABLE IF NOT EXISTS departments
(
    id                     VARCHAR(255) PRIMARY KEY,
    name                   VARCHAR(255) NOT NULL UNIQUE,
    location               VARCHAR(255) NOT NULL UNIQUE,
    created_at             TIMESTAMP WITHOUT TIME ZONE,
    updated_at             TIMESTAMP WITHOUT TIME ZONE
);

CREATE TABLE IF NOT EXISTS employees
(
    id            VARCHAR(255) PRIMARY KEY,
    name          VARCHAR(255),
    position     VARCHAR(255),
    email         VARCHAR(255) NOT NULL UNIQUE,
    salary        DECIMAL(10, 2),
    created_at    TIMESTAMP WITHOUT TIME ZONE,
    updated_at    TIMESTAMP WITHOUT TIME ZONE,
    department_id VARCHAR(255) NOT NULL,
    FOREIGN KEY (department_id) REFERENCES departments (id)
);
